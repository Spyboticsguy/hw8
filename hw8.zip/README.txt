File Locations:
	The python files are located as follows (with "/" being the root directory of the project):
	/performanceCode.py
	/filming/filmingActingCode.py
		- combined filmingCode.py and actingCode.py
	/effects/effectCode.py
	
	The movie file was uploaded seperately. If you cannot open the movie, there is an online version hosted at the following link:
		https://youtu.be/F9n6xehimQ8
	
	The project and team write-ups were uploaded individually.
	
Important Notes:
	Please do not move any of the files located in this ZIP file. They depend on hard-coded local file locations, relative to the root
	of the ZIP.
	
	Thank you!